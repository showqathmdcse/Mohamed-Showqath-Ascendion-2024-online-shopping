package com.example.shopping.service;

import com.example.shopping.dto.Cart;
import com.example.shopping.repo.CartCustom;
import com.example.shopping.repo.CartRepo;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CartImpl implements CartService{

    @PersistenceContext
    private EntityManager em;

    @Autowired
    CartRepo cre;

    @Autowired
    CartCustom cc;

    @Override
    public Cart add(Cart c) {
        return cre.save(c);
    }

    @Override
    public Cart update(Cart c) {
        return null;
    }

    @Override
    public void delete(Cart c) {

    }

    @Override
    public List<Cart> display() {
        return List.of();
    }

    @Override
    public void addtocart(int custId, int prodId) {
        cc.addtocart(custId,prodId);
    }


}
