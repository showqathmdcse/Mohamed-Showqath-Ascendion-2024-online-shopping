package com.example.shopping.dto;


import jakarta.persistence.*;
import lombok.*;

@Entity
@Getter
@Setter
@ToString
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode
public class CartProduct {
    @Id
    @GeneratedValue
    private int cpId;
    private int price;
    private int totalPrice;
    private int quant;

    @OneToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
    private Product product;

  @ManyToOne(cascade = CascadeType.ALL,fetch = FetchType.EAGER)
  @JoinColumn
    private Cart cart;
}
