package com.example.shopping.service;

import com.example.shopping.dto.Inventry;

import java.util.List;

public interface InventryService {
    public Inventry save(Inventry in);
    public Inventry upd(Inventry in);
    public void delete(int id);
    public List<Inventry> findByStatus(String status);
















































}
