package com.example.shopping.service;

import com.example.shopping.dto.Inventry;
import com.example.shopping.dto.Product;
import com.example.shopping.repo.InventrRepo;
import com.example.shopping.repo.ProdRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class InvSerImpl implements InventryService {

    @Autowired
    InventrRepo in;


    @Override
    public Inventry save(Inventry n) {
        return in.save(n);
    }

    @Override
    public Inventry upd(Inventry n) {
        return in.save(n);
    }

    @Override
    public void delete(int id) {
         in.deleteById(id);
    }

    @Override
    public List<Inventry> findByStatus(String status) {
        return in.findByStockStaus(status);
    }
}
