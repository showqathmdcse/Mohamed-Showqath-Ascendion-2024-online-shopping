package com.example.shopping.controller;


import com.example.shopping.dto.Cart;
import com.example.shopping.dto.Product;
import com.example.shopping.repo.CartCustom;
import com.example.shopping.repo.CustomerRepo;
import com.example.shopping.service.CartService;
import com.example.shopping.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/shop/cart")
public class CartController {
    @Autowired
    CartService cs;

    @Autowired
    CartCustom cc;


    @PostMapping("/addtocart")
    public void  add(@RequestParam("custId")int id, @RequestParam("prodId")int prodId){
      cc.addtocart(id,prodId);


    }

}
