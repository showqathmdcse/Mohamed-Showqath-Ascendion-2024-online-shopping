package com.example.shopping.repo;

import com.example.shopping.dto.Cart;
import com.example.shopping.dto.CartProduct;
import com.example.shopping.dto.Customer;
import com.example.shopping.dto.Product;
import com.example.shopping.service.CustomerService;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class CartCustomIMpl implements CartCustom {
    @PersistenceContext

    @Autowired
    private EntityManager em;

    @Autowired
    CartRepo cr;


    @Transactional
    public void addtocart(int custId, int prodId){
        Customer customer = em.find(Customer.class,custId);
        Cart cart = customer.getCart();
//        Cart cart=em.find(Cart.class,custId);
        if(cart!=null) {
            Product p1=em.find(Product.class,prodId);
            List<CartProduct> cp=cart.getCp();
            boolean exist=false;
            int cpi=0;
            for(CartProduct ce:cp){
                if(ce.getProduct()==p1){
                    cpi=ce.getCpId();
                    exist=true;
                    break;
                }
            }
            if(exist){
                for(CartProduct cd:cp){
                    if(cd.getCpId()==cpi){
                        cd.setTotalPrice(cd.getTotalPrice()+cd.getPrice());
                        cd.setQuant(cd.getQuant()+1);
                    }
                }
            }
            else{
                CartProduct cd=new CartProduct();
                cd.setProduct(p1);
                cd.setQuant(1);
                cd.setTotalPrice(p1.getProdPrice());
                cd.setPrice(p1.getProdPrice());
                cart.getCp().add(cd);
                em.persist(cd);
            }
            customer.setCart(cart);
            em.persist(customer);

        }
        else{
            Cart cart2=new Cart();
//            cart2.setCartId(23);
            cart2.setCustomer(customer);
            Product p1=em.find(Product.class,prodId);
            List<CartProduct> cp=cart2.getCp();
            boolean exist=false;
            int cpi=0;
            for(CartProduct ce:cp){
                if(ce.getProduct()==p1){
                    cpi=ce.getCpId();
                    exist=true;
                    break;
                }
            }
            if(exist){
                for(CartProduct cd:cp){
                    if(cd.getCpId()==cpi){
                        cd.setTotalPrice(cd.getTotalPrice()+cd.getPrice());
                        cd.setQuant(cd.getQuant()+1);
                    }
                }
            }
            else{
                CartProduct cd=new CartProduct();
                cd.setProduct(p1);
                cd.setQuant(1);
                cd.setTotalPrice(p1.getProdPrice());
                cd.setPrice(p1.getProdPrice());
                cart2.getCp().add(cd);
                em.persist(cd);
            }
            customer.setCart(cart2);
            em.persist(customer);
        }
    }
}
