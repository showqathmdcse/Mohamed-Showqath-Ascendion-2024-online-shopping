package com.example.shopping.repo;


import com.example.shopping.dto.Cart;
import com.example.shopping.dto.Customer;
import com.example.shopping.dto.Product;
import org.springframework.stereotype.Repository;


public interface CartCustom {
    public void addtocart(int custId,int prodId);
}
